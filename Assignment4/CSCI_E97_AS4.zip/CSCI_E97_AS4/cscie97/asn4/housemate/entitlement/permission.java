/**
 * 
 */
package cscie97.asn4.housemate.entitlement;

/**
 * permission Class - extends privilege abstract class
 *
 */
public class permission extends privilege{

	public permission(String ID, String new_name, String descript){
		super(ID, new_name, descript);	
	}
}
